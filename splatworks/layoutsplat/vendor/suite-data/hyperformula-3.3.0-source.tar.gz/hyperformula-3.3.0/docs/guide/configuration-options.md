# Configuration options

HyperFormula can be customized through easy-to-setup `options`.

The only mandatory key is `licenseKey`. It has a
[dedicated section](license-key.md) in which you can find all allowed
types of key values.

Below you can see the example of a configuration object and the
static method called to initiate a new instance of HyperFormula.

[See the full list of available options &#8594;](../api/interfaces/configparams.html)

## Example

```javascript
// define options 
const options = {
    licenseKey: 'gpl-v3',
    precisionRounding: 9,
    nullDate: { year: 1900, month: 1, day: 1 },
    functionArgSeparator: '.'
};

// call the static method to build a new instance
const hfInstance = HyperFormula.buildEmpty(options);
```