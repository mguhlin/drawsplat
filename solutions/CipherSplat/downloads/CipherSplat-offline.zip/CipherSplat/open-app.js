(() => {
  const script = document.currentScript;
  const target = location.protocol === 'file:' ? script.dataset.file : script.dataset.host;
  location.replace(new URL(target, location.href).href);
})();
